
#import <UIKit/UIKit.h>

//! Project version number for AisleNetworking.
FOUNDATION_EXPORT double AisleNetworkingVersionNumber;

//! Project version string for AisleNetworking.
FOUNDATION_EXPORT const unsigned char AisleNetworkingVersionString[];

